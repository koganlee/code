#include <stdio.h>

void multi(int,int);
void sub(int,int);
int main()
{
	printf("I am need make\n");
	multi(4,5);
	multi(4,5);
	sub(4,5);
	return 5;
}
