#include <stdio.h>

void sub(int i,int j)
{
	printf("sub=%d\n",i-j);
}
