#include <stdio.h>
void multi(int i,int j)
{
	printf("multi=%d\n",i*j);
}

