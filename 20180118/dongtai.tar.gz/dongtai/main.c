#include <stdio.h>
float muti(float n1, float n2);
int main()
{
   float a, b;
   scanf("%f %f", &a, &b);
   
   printf(" a * b = %.2f\n",muti(a,b));
}
