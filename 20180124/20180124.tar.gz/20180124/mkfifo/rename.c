#include "func.h"
//只支持当前目录的重命名
int main(int argc,char *argv[])
{
	if(argc!=3)
	{
		printf("error args\n");
		return -1;
	}
	int ret;
	printf("EISDIR=%d\n",EISDIR);
	ret=rename(argv[1],argv[2]);
	if(-1==ret)
	{
		printf("errno=%d\n",errno);
		perror("rename");
		return -1;
	}
	return 0;
}
