#include <stdio.h>

int main()
{
	printf("I am print process\n");
	return 0;
}
