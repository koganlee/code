#include <stdio.h>
#include <stdlib.h>
int main(int argc,char *argv[])
{
	int i=atoi(argv[1]);
	int j=atoi(argv[2]);
	printf("sum=%d\n",i+j);
	return 0;
}
