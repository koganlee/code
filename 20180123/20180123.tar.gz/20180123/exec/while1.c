#include <stdio.h>
#include <stdlib.h>
int main(int argc,char *argv[])
{
	printf("I am while\n");
	while(1);
	return 0;
}
