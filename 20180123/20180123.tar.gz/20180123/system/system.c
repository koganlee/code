#include <stdlib.h>
#include <stdio.h>

int main()
{
	system("ls -l");
	printf("after ls\n");
	return 0;
}
