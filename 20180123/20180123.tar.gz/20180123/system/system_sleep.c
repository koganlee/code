#include <stdlib.h>
#include <stdio.h>

int main()
{
	system("sleep 10");
	printf("after ls\n");
	return 0;
}
